import React from 'react'
import ProductsPage from './features/products/ProductsPage'

export default function App() {
  return <ProductsPage />
}
